Subject Name:  TEST_REGRESSION
Subject ID:  DEV
Study Date:  20180918
Study ID:  27018
Accession Number:  00000000
Station Name:  fmrif3tb
  Series:mr_0001, Slices:00027, Organized:20180918_11:43, Description:(MRImageStorage)3plane_loc_ssfse 
  Series:mr_0003, Slices:00150, Organized:20180918_11:47, Description:(MRImageStorage)axial_epi_fmri_interleaved_i_to_s 
  Series:mr_0004, Slices:00150, Organized:20180918_11:50, Description:(MRImageStorage)axial_epi_fmri_interleaved_i_to_s 
  Series:mr_0005, Slices:00150, Organized:20180918_11:54, Description:(MRImageStorage)axial_epi_fmri_sequential_i_to_s 
  Series:mr_0006, Slices:00150, Organized:20180918_11:56, Description:(MRImageStorage)axial_epi_fmri_interleaved_s_to_i 
  Series:mr_0007, Slices:00150, Organized:20180918_11:57, Description:(MRImageStorage)axial_epi_fmri_sequential_s_to_i 

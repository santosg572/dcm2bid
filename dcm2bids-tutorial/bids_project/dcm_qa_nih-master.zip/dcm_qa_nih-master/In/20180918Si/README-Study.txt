Subject Name:  TEST_REGRESSION
Subject ID:  DEV
Study Date:  20180918
Study ID:  00001
Accession Number:  00000000
Station Name:  AWP45160
  Series:mr_0001, Slices:00003, Organized:20180918_12:16, Description:(MRImageStorage)localizer 
  Series:mr_0002, Slices:00003, Organized:20180918_12:22, Description:(MRImageStorage)localizer 
  Series:mr_0003, Slices:00002, Organized:20180918_12:25, Description:(MRImageStorage)epi_pe_ap 
  Series:mr_0004, Slices:00002, Organized:20180918_12:28, Description:(MRImageStorage)epi_pe_pa 
  Series:mr_0005, Slices:00002, Organized:20180918_12:29, Description:(MRImageStorage)epi_pe_rl 
  Series:mr_0006, Slices:00002, Organized:20180918_12:30, Description:(MRImageStorage)epi_pe_lr 
